import { useState, useEffect, useRef, useCallback } from "react";

const PLANS = [
  {
    id: "free",
    name: "Free",
    price: 0,
    features: ["Text Chat", "Random Matching", "5 Chats/Day", "Basic Filters"],
    color: "#6b7280",
    popular: false,
  },
  {
    id: "pro",
    name: "Pro",
    price: 499,
    features: [
      "Video + Text Chat",
      "Unlimited Chats",
      "Interest Matching",
      "No Ads",
      "Priority Queue",
    ],
    color: "#f59e0b",
    popular: true,
  },
  {
    id: "elite",
    name: "Elite",
    price: 999,
    features: [
      "Everything in Pro",
      "Gender Filter",
      "Location Filter",
      "Verified Badge",
      "VIP Support",
      "Chat History",
    ],
    color: "#8b5cf6",
    popular: false,
  },
];

const INTERESTS = [
  "Gaming", "Music", "Movies", "Tech", "Sports", "Art",
  "Travel", "Cooking", "Fitness", "Books", "Anime", "Science",
  "Photography", "Fashion", "Coding", "Crypto", "Pets", "Comedy",
];

const FAKE_MESSAGES_POOL = [
  "Hey! What's up?", "Where are you from?", "Nice to meet you!",
  "What are your hobbies?", "Do you like music?", "This is fun lol",
  "What do you do for work?", "Any favorite movies?",
];

// ─── Icons ────────────────────────────────────────────
const VideoIcon = () => (
  <svg width="22" height="22" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
    <polygon points="23 7 16 12 23 17 23 7" />
    <rect x="1" y="5" width="15" height="14" rx="2" ry="2" />
  </svg>
);
const ChatIcon = () => (
  <svg width="22" height="22" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
  </svg>
);
const SkipIcon = () => (
  <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
    <polygon points="5 4 15 12 5 20 5 4" />
    <line x1="19" y1="5" x2="19" y2="19" />
  </svg>
);
const StopIcon = () => (
  <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24">
    <rect x="4" y="4" width="16" height="16" rx="2" />
  </svg>
);
const SendIcon = () => (
  <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
    <line x1="22" y1="2" x2="11" y2="13" />
    <polygon points="22 2 15 22 11 13 2 9 22 2" />
  </svg>
);
const CrownIcon = () => (
  <svg width="18" height="18" fill="currentColor" viewBox="0 0 24 24">
    <path d="M2 20h20L19 8l-5 6-2-8-2 8-5-6z" />
  </svg>
);
const MicIcon = ({ muted }) => (
  <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
    <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z" />
    <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
    <line x1="12" y1="19" x2="12" y2="23" />
    <line x1="8" y1="23" x2="16" y2="23" />
    {muted && <line x1="1" y1="1" x2="23" y2="23" stroke="#ef4444" strokeWidth="3" />}
  </svg>
);
const CamIcon = ({ off }) => (
  <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
    <polygon points="23 7 16 12 23 17 23 7" />
    <rect x="1" y="5" width="15" height="14" rx="2" ry="2" />
    {off && <line x1="1" y1="1" x2="23" y2="23" stroke="#ef4444" strokeWidth="3" />}
  </svg>
);
const CheckIcon = () => (
  <svg width="16" height="16" fill="none" stroke="#22c55e" strokeWidth="3" viewBox="0 0 24 24">
    <polyline points="20 6 9 17 4 12" />
  </svg>
);

// ─── Main App ─────────────────────────────────────────
export default function App() {
  const [page, setPage] = useState("home");
  const [user, setUser] = useState(null);
  const [subscription, setSubscription] = useState("free");
  const [showAuth, setShowAuth] = useState(false);
  const [authMode, setAuthMode] = useState("login");
  const [chatMode, setChatMode] = useState(null);
  const [onlineCount] = useState(Math.floor(Math.random() * 8000) + 12000);

  const handleStartChat = (mode) => {
    if (!user) {
      setShowAuth(true);
      return;
    }
    if (mode === "video" && subscription === "free") {
      setPage("pricing");
      return;
    }
    setChatMode(mode);
    setPage("chat");
  };

  const handleAuth = (userData) => {
    setUser(userData);
    setShowAuth(false);
  };

  const handleSubscribe = (planId) => {
    if (!user) {
      setShowAuth(true);
      return;
    }
    setSubscription(planId);
    setPage("home");
  };

  return (
    <div style={styles.app}>
      <style>{globalCSS}</style>

      {/* Nav */}
      <nav style={styles.nav}>
        <div style={styles.navInner}>
          <div style={styles.logo} onClick={() => setPage("home")}>
            <span style={styles.logoIcon}>⚡</span>
            <span style={styles.logoText}>MeetWave</span>
          </div>
          <div style={styles.navLinks}>
            <span style={styles.onlineBadge}>
              <span style={styles.onlineDot} />
              {onlineCount.toLocaleString()} online
            </span>
            <button style={styles.navBtn} onClick={() => setPage("pricing")}>
              <CrownIcon /> Plans
            </button>
            {user ? (
              <div style={styles.userBadge}>
                <div style={styles.avatar}>{user.name[0].toUpperCase()}</div>
                <span style={styles.userName}>{user.name}</span>
                {subscription !== "free" && (
                  <span style={{ ...styles.subBadge, background: PLANS.find((p) => p.id === subscription)?.color }}>
                    {subscription.toUpperCase()}
                  </span>
                )}
              </div>
            ) : (
              <button style={styles.authBtn} onClick={() => setShowAuth(true)}>
                Sign In
              </button>
            )}
          </div>
        </div>
      </nav>

      {/* Pages */}
      <main style={styles.main}>
        {page === "home" && (
          <HomePage
            onStartChat={handleStartChat}
            subscription={subscription}
            onlineCount={onlineCount}
          />
        )}
        {page === "pricing" && (
          <PricingPage
            currentPlan={subscription}
            onSubscribe={handleSubscribe}
          />
        )}
        {page === "chat" && (
          <ChatPage
            mode={chatMode}
            subscription={subscription}
            onBack={() => setPage("home")}
            userName={user?.name || "You"}
          />
        )}
      </main>

      {/* Auth Modal */}
      {showAuth && (
        <AuthModal
          mode={authMode}
          onSwitchMode={() => setAuthMode(authMode === "login" ? "signup" : "login")}
          onAuth={handleAuth}
          onClose={() => setShowAuth(false)}
        />
      )}
    </div>
  );
}

// ─── Home Page ────────────────────────────────────────
function HomePage({ onStartChat, subscription, onlineCount }) {
  const [selectedInterests, setSelectedInterests] = useState([]);

  const toggleInterest = (i) => {
    setSelectedInterests((prev) =>
      prev.includes(i) ? prev.filter((x) => x !== i) : prev.length < 5 ? [...prev, i] : prev
    );
  };

  return (
    <div style={styles.homeContainer}>
      {/* Hero */}
      <div style={styles.hero}>
        <div style={styles.heroGlow} />
        <h1 style={styles.heroTitle}>
          Meet Someone <span style={styles.heroHighlight}>New</span>
        </h1>
        <p style={styles.heroSub}>
          Connect with random people worldwide through video & text chat. Safe, anonymous, instant.
        </p>

        {/* Action Buttons */}
        <div style={styles.actionRow}>
          <button style={styles.videoChatBtn} onClick={() => onStartChat("video")}>
            <VideoIcon />
            <span>Video Chat</span>
            {subscription === "free" && <span style={styles.proBadge}>PRO</span>}
          </button>
          <button style={styles.textChatBtn} onClick={() => onStartChat("text")}>
            <ChatIcon />
            <span>Text Chat</span>
          </button>
        </div>

        {/* Interests */}
        <div style={styles.interestsSection}>
          <p style={styles.interestsLabel}>Select Interests (optional):</p>
          <div style={styles.interestsGrid}>
            {INTERESTS.map((interest) => (
              <button
                key={interest}
                style={{
                  ...styles.interestChip,
                  ...(selectedInterests.includes(interest) ? styles.interestChipActive : {}),
                }}
                onClick={() => toggleInterest(interest)}
              >
                {interest}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Stats */}
      <div style={styles.statsRow}>
        {[
          { label: "Online Now", value: onlineCount.toLocaleString(), color: "#22c55e" },
          { label: "Chats Today", value: "1.2M+", color: "#3b82f6" },
          { label: "Countries", value: "190+", color: "#f59e0b" },
        ].map((s) => (
          <div key={s.label} style={styles.statCard}>
            <div style={{ ...styles.statValue, color: s.color }}>{s.value}</div>
            <div style={styles.statLabel}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Features */}
      <div style={styles.featuresGrid}>
        {[
          { icon: "🔒", title: "Anonymous & Safe", desc: "No personal info required. Chat freely." },
          { icon: "⚡", title: "Instant Matching", desc: "Connect with someone in under 3 seconds." },
          { icon: "🌍", title: "Global Community", desc: "People from 190+ countries, 24/7." },
          { icon: "🎭", title: "Interest Matching", desc: "Find people who share your passions." },
        ].map((f) => (
          <div key={f.title} style={styles.featureCard}>
            <span style={styles.featureIcon}>{f.icon}</span>
            <h3 style={styles.featureTitle}>{f.title}</h3>
            <p style={styles.featureDesc}>{f.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Pricing Page ─────────────────────────────────────
function PricingPage({ currentPlan, onSubscribe }) {
  return (
    <div style={styles.pricingContainer}>
      <h2 style={styles.pricingTitle}>Choose Your Plan</h2>
      <p style={styles.pricingSub}>Unlock premium features for the best experience</p>

      <div style={styles.plansGrid}>
        {PLANS.map((plan) => (
          <div
            key={plan.id}
            style={{
              ...styles.planCard,
              ...(plan.popular ? styles.planCardPopular : {}),
              borderColor: plan.popular ? plan.color : "rgba(255,255,255,0.08)",
            }}
          >
            {plan.popular && <div style={{ ...styles.popularTag, background: plan.color }}>MOST POPULAR</div>}
            <h3 style={{ ...styles.planName, color: plan.color }}>{plan.name}</h3>
            <div style={styles.planPrice}>
              {plan.price === 0 ? (
                <span style={styles.priceAmount}>Free</span>
              ) : (
                <>
                  <span style={styles.priceCurrency}>₹</span>
                  <span style={styles.priceAmount}>{plan.price}</span>
                  <span style={styles.priceInterval}>/mo</span>
                </>
              )}
            </div>
            <ul style={styles.featuresList}>
              {plan.features.map((f) => (
                <li key={f} style={styles.featureItem}>
                  <CheckIcon /> {f}
                </li>
              ))}
            </ul>
            <button
              style={{
                ...styles.planBtn,
                background: currentPlan === plan.id ? "rgba(255,255,255,0.1)" : plan.color,
                cursor: currentPlan === plan.id ? "default" : "pointer",
              }}
              onClick={() => currentPlan !== plan.id && onSubscribe(plan.id)}
            >
              {currentPlan === plan.id ? "Current Plan" : plan.price === 0 ? "Get Started" : "Subscribe Now"}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Chat Page ────────────────────────────────────────
function ChatPage({ mode, subscription, onBack, userName }) {
  const [status, setStatus] = useState("searching");
  const [messages, setMessages] = useState([]);
  const [inputMsg, setInputMsg] = useState("");
  const [micMuted, setMicMuted] = useState(false);
  const [camOff, setCamOff] = useState(false);
  const [strangerTyping, setStrangerTyping] = useState(false);
  const chatEndRef = useRef(null);
  const videoRef = useRef(null);
  const searchTimerRef = useRef(null);
  const botTimerRef = useRef(null);

  // Simulate finding a match
  useEffect(() => {
    setStatus("searching");
    setMessages([]);
    const delay = Math.random() * 2000 + 1500;
    searchTimerRef.current = setTimeout(() => {
      setStatus("connected");
      setMessages([{ type: "system", text: "You are now connected with a stranger!" }]);
      scheduleBotMessage();
    }, delay);
    return () => {
      clearTimeout(searchTimerRef.current);
      clearTimeout(botTimerRef.current);
    };
  }, []);

  // Start local camera for video mode
  useEffect(() => {
    if (mode === "video" && videoRef.current) {
      navigator.mediaDevices
        ?.getUserMedia({ video: true, audio: true })
        .then((stream) => {
          if (videoRef.current) videoRef.current.srcObject = stream;
        })
        .catch(() => {});
    }
  }, [mode, status]);

  const scheduleBotMessage = () => {
    const delay = Math.random() * 4000 + 2000;
    botTimerRef.current = setTimeout(() => {
      setStrangerTyping(true);
      setTimeout(() => {
        const msg = FAKE_MESSAGES_POOL[Math.floor(Math.random() * FAKE_MESSAGES_POOL.length)];
        setMessages((prev) => [...prev, { type: "stranger", text: msg }]);
        setStrangerTyping(false);
        scheduleBotMessage();
      }, Math.random() * 1500 + 800);
    }, delay);
  };

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, strangerTyping]);

  const sendMessage = () => {
    if (!inputMsg.trim()) return;
    setMessages((prev) => [...prev, { type: "you", text: inputMsg.trim() }]);
    setInputMsg("");
  };

  const skipStranger = () => {
    clearTimeout(botTimerRef.current);
    setStatus("searching");
    setMessages([]);
    setStrangerTyping(false);
    const delay = Math.random() * 2000 + 1000;
    searchTimerRef.current = setTimeout(() => {
      setStatus("connected");
      setMessages([{ type: "system", text: "You are now connected with a stranger!" }]);
      scheduleBotMessage();
    }, delay);
  };

  const stopChat = () => {
    clearTimeout(botTimerRef.current);
    clearTimeout(searchTimerRef.current);
    setMessages((prev) => [...prev, { type: "system", text: "You have disconnected." }]);
    setStatus("disconnected");
  };

  return (
    <div style={styles.chatContainer}>
      {/* Video Area */}
      {mode === "video" && (
        <div style={styles.videoArea}>
          <div style={styles.strangerVideo}>
            {status === "connected" ? (
              <div style={styles.videoPlaceholder}>
                <div style={styles.strangerAvatar}>👤</div>
                <p style={{ color: "#9ca3af", fontSize: 14 }}>Stranger's Camera</p>
              </div>
            ) : status === "searching" ? (
              <div style={styles.videoPlaceholder}>
                <div style={styles.searchingSpinner} />
                <p style={{ color: "#9ca3af", fontSize: 14, marginTop: 16 }}>Finding someone...</p>
              </div>
            ) : (
              <div style={styles.videoPlaceholder}>
                <p style={{ color: "#9ca3af" }}>Disconnected</p>
              </div>
            )}
          </div>
          <div style={styles.selfVideo}>
            <video ref={videoRef} autoPlay muted playsInline style={styles.selfVideoEl} />
            {camOff && (
              <div style={styles.camOffOverlay}>
                <span style={{ fontSize: 28 }}>📷</span>
                <span style={{ fontSize: 12, color: "#9ca3af" }}>Camera Off</span>
              </div>
            )}
          </div>
          {/* Video Controls */}
          <div style={styles.videoControls}>
            <button
              style={{ ...styles.controlBtn, background: micMuted ? "#ef4444" : "rgba(255,255,255,0.1)" }}
              onClick={() => setMicMuted(!micMuted)}
            >
              <MicIcon muted={micMuted} />
            </button>
            <button
              style={{ ...styles.controlBtn, background: camOff ? "#ef4444" : "rgba(255,255,255,0.1)" }}
              onClick={() => setCamOff(!camOff)}
            >
              <CamIcon off={camOff} />
            </button>
          </div>
        </div>
      )}

      {/* Chat Area */}
      <div style={{ ...styles.chatArea, height: mode === "video" ? "40%" : "100%" }}>
        {/* Chat Header */}
        <div style={styles.chatHeader}>
          <button style={styles.backBtn} onClick={onBack}>
            ← Back
          </button>
          <div style={styles.chatStatus}>
            {status === "searching" && (
              <>
                <span style={styles.searchDot} /> Finding stranger...
              </>
            )}
            {status === "connected" && (
              <>
                <span style={{ ...styles.onlineDot, marginRight: 6 }} /> Connected to Stranger
              </>
            )}
            {status === "disconnected" && "Disconnected"}
          </div>
          <div style={styles.chatActions}>
            <button style={styles.skipBtn} onClick={skipStranger} disabled={status === "searching"}>
              <SkipIcon /> Next
            </button>
            <button style={styles.stopBtn} onClick={stopChat} disabled={status !== "connected"}>
              <StopIcon /> Stop
            </button>
          </div>
        </div>

        {/* Messages */}
        <div style={styles.messagesArea}>
          {messages.map((msg, i) => (
            <div
              key={i}
              style={{
                ...styles.messageBubble,
                ...(msg.type === "you"
                  ? styles.youBubble
                  : msg.type === "stranger"
                  ? styles.strangerBubble
                  : styles.systemBubble),
              }}
            >
              {msg.type !== "system" && (
                <span style={styles.msgSender}>{msg.type === "you" ? userName : "Stranger"}</span>
              )}
              {msg.text}
            </div>
          ))}
          {strangerTyping && (
            <div style={{ ...styles.messageBubble, ...styles.strangerBubble }}>
              <span style={styles.msgSender}>Stranger</span>
              <span style={styles.typingDots}>
                <span className="dot-anim">•</span>
                <span className="dot-anim" style={{ animationDelay: "0.2s" }}>•</span>
                <span className="dot-anim" style={{ animationDelay: "0.4s" }}>•</span>
              </span>
            </div>
          )}
          <div ref={chatEndRef} />
        </div>

        {/* Input */}
        <div style={styles.inputArea}>
          <input
            style={styles.chatInput}
            placeholder={status === "connected" ? "Type a message..." : "Waiting for connection..."}
            value={inputMsg}
            onChange={(e) => setInputMsg(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && sendMessage()}
            disabled={status !== "connected"}
          />
          <button style={styles.sendBtn} onClick={sendMessage} disabled={status !== "connected"}>
            <SendIcon />
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Auth Modal ───────────────────────────────────────
function AuthModal({ mode, onSwitchMode, onAuth, onClose }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = () => {
    if (!email || !password || (mode === "signup" && !name)) return;
    onAuth({ name: name || email.split("@")[0], email });
  };

  return (
    <div style={styles.modalOverlay} onClick={onClose}>
      <div style={styles.modalContent} onClick={(e) => e.stopPropagation()}>
        <button style={styles.modalClose} onClick={onClose}>✕</button>
        <h2 style={styles.modalTitle}>{mode === "login" ? "Welcome Back" : "Create Account"}</h2>
        <p style={styles.modalSub}>
          {mode === "login" ? "Sign in to continue chatting" : "Join MeetWave for free"}
        </p>

        {mode === "signup" && (
          <input
            style={styles.modalInput}
            placeholder="Username"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        )}
        <input
          style={styles.modalInput}
          placeholder="Email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          style={styles.modalInput}
          placeholder="Password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
        />

        <button style={styles.modalSubmitBtn} onClick={handleSubmit}>
          {mode === "login" ? "Sign In" : "Sign Up"}
        </button>

        <div style={styles.divider}>
          <span style={styles.dividerLine} />
          <span style={styles.dividerText}>or</span>
          <span style={styles.dividerLine} />
        </div>

        <button style={styles.googleBtn}>
          <svg width="18" height="18" viewBox="0 0 24 24">
            <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" />
            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
            <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
          </svg>
          Continue with Google
        </button>

        <p style={styles.switchAuth}>
          {mode === "login" ? "Don't have an account?" : "Already have an account?"}
          <button style={styles.switchBtn} onClick={onSwitchMode}>
            {mode === "login" ? "Sign Up" : "Sign In"}
          </button>
        </p>
      </div>
    </div>
  );
}

// ─── Global CSS ───────────────────────────────────────
const globalCSS = `
  @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap');

  * { margin:0; padding:0; box-sizing:border-box; }
  body { font-family: 'Outfit', sans-serif; background: #0a0a0f; color: #e5e7eb; overflow-x:hidden; }
  ::-webkit-scrollbar { width: 6px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 3px; }

  @keyframes pulse-glow {
    0%, 100% { opacity: 0.4; transform: scale(1); }
    50% { opacity: 0.8; transform: scale(1.05); }
  }
  @keyframes spin {
    to { transform: rotate(360deg); }
  }
  @keyframes dotBounce {
    0%, 80%, 100% { opacity: 0.3; }
    40% { opacity: 1; }
  }
  .dot-anim {
    animation: dotBounce 1.2s infinite;
    font-size: 20px;
    line-height: 1;
  }
  @keyframes float {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-8px); }
  }
`;

// ─── Styles ───────────────────────────────────────────
const styles = {
  app: { minHeight: "100vh", background: "#0a0a0f", fontFamily: "'Outfit', sans-serif" },

  // Nav
  nav: {
    position: "sticky", top: 0, zIndex: 100,
    background: "rgba(10,10,15,0.85)", backdropFilter: "blur(20px)",
    borderBottom: "1px solid rgba(255,255,255,0.06)",
    padding: "0 24px",
  },
  navInner: {
    maxWidth: 1200, margin: "0 auto", height: 64,
    display: "flex", alignItems: "center", justifyContent: "space-between",
  },
  logo: { display: "flex", alignItems: "center", gap: 8, cursor: "pointer" },
  logoIcon: { fontSize: 28, filter: "drop-shadow(0 0 8px rgba(59,130,246,0.5))" },
  logoText: { fontSize: 22, fontWeight: 800, letterSpacing: -0.5, background: "linear-gradient(135deg, #3b82f6, #8b5cf6)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" },
  navLinks: { display: "flex", alignItems: "center", gap: 16 },
  onlineBadge: { display: "flex", alignItems: "center", gap: 6, fontSize: 13, color: "#9ca3af", fontFamily: "'JetBrains Mono', monospace" },
  onlineDot: { width: 8, height: 8, borderRadius: "50%", background: "#22c55e", boxShadow: "0 0 8px rgba(34,197,94,0.6)" },
  navBtn: { display: "flex", alignItems: "center", gap: 6, padding: "8px 14px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 10, color: "#e5e7eb", fontSize: 13, fontWeight: 500, cursor: "pointer", fontFamily: "inherit" },
  authBtn: { padding: "8px 20px", background: "linear-gradient(135deg, #3b82f6, #6366f1)", border: "none", borderRadius: 10, color: "#fff", fontSize: 13, fontWeight: 600, cursor: "pointer", fontFamily: "inherit" },
  userBadge: { display: "flex", alignItems: "center", gap: 8 },
  avatar: { width: 32, height: 32, borderRadius: "50%", background: "linear-gradient(135deg, #3b82f6, #8b5cf6)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, fontWeight: 700, color: "#fff" },
  userName: { fontSize: 14, fontWeight: 500 },
  subBadge: { padding: "2px 8px", borderRadius: 6, fontSize: 10, fontWeight: 700, color: "#fff", letterSpacing: 0.5 },

  // Main
  main: { maxWidth: 1200, margin: "0 auto", padding: "0 24px" },

  // Home
  homeContainer: { paddingBottom: 80 },
  hero: { textAlign: "center", padding: "80px 0 40px", position: "relative" },
  heroGlow: { position: "absolute", top: -100, left: "50%", transform: "translateX(-50%)", width: 600, height: 600, borderRadius: "50%", background: "radial-gradient(circle, rgba(59,130,246,0.12) 0%, transparent 70%)", pointerEvents: "none" },
  heroTitle: { fontSize: "clamp(36px, 6vw, 64px)", fontWeight: 800, lineHeight: 1.1, letterSpacing: -1.5, marginBottom: 16 },
  heroHighlight: { background: "linear-gradient(135deg, #3b82f6, #a855f7, #ec4899)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" },
  heroSub: { fontSize: 18, color: "#9ca3af", maxWidth: 500, margin: "0 auto 40px", lineHeight: 1.6 },

  actionRow: { display: "flex", gap: 16, justifyContent: "center", marginBottom: 40, flexWrap: "wrap" },
  videoChatBtn: { display: "flex", alignItems: "center", gap: 10, padding: "16px 32px", background: "linear-gradient(135deg, #3b82f6, #6366f1)", border: "none", borderRadius: 14, color: "#fff", fontSize: 16, fontWeight: 600, cursor: "pointer", fontFamily: "inherit", position: "relative", transition: "transform 0.2s, box-shadow 0.2s", boxShadow: "0 4px 24px rgba(59,130,246,0.3)" },
  textChatBtn: { display: "flex", alignItems: "center", gap: 10, padding: "16px 32px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 14, color: "#fff", fontSize: 16, fontWeight: 600, cursor: "pointer", fontFamily: "inherit", transition: "transform 0.2s" },
  proBadge: { padding: "2px 8px", background: "#f59e0b", borderRadius: 6, fontSize: 10, fontWeight: 700, letterSpacing: 0.5 },

  interestsSection: { maxWidth: 600, margin: "0 auto" },
  interestsLabel: { fontSize: 14, color: "#9ca3af", marginBottom: 12 },
  interestsGrid: { display: "flex", flexWrap: "wrap", gap: 8, justifyContent: "center" },
  interestChip: { padding: "6px 16px", borderRadius: 20, background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)", color: "#9ca3af", fontSize: 13, fontWeight: 500, cursor: "pointer", fontFamily: "inherit", transition: "all 0.2s" },
  interestChipActive: { background: "rgba(59,130,246,0.15)", borderColor: "#3b82f6", color: "#60a5fa" },

  statsRow: { display: "flex", gap: 20, justifyContent: "center", margin: "60px 0", flexWrap: "wrap" },
  statCard: { textAlign: "center", padding: "24px 40px", background: "rgba(255,255,255,0.03)", borderRadius: 16, border: "1px solid rgba(255,255,255,0.06)" },
  statValue: { fontSize: 32, fontWeight: 800, fontFamily: "'JetBrains Mono', monospace" },
  statLabel: { fontSize: 14, color: "#6b7280", marginTop: 4, fontWeight: 500 },

  featuresGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 20, marginTop: 20 },
  featureCard: { padding: 28, background: "rgba(255,255,255,0.02)", borderRadius: 16, border: "1px solid rgba(255,255,255,0.06)", transition: "border-color 0.3s" },
  featureIcon: { fontSize: 32, display: "block", marginBottom: 12 },
  featureTitle: { fontSize: 16, fontWeight: 700, marginBottom: 6 },
  featureDesc: { fontSize: 14, color: "#9ca3af", lineHeight: 1.5 },

  // Pricing
  pricingContainer: { padding: "60px 0 80px", textAlign: "center" },
  pricingTitle: { fontSize: 40, fontWeight: 800, letterSpacing: -1, marginBottom: 8 },
  pricingSub: { fontSize: 16, color: "#9ca3af", marginBottom: 48 },
  plansGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 24, maxWidth: 960, margin: "0 auto" },
  planCard: { padding: 32, background: "rgba(255,255,255,0.02)", borderRadius: 20, border: "2px solid rgba(255,255,255,0.08)", textAlign: "left", position: "relative", transition: "transform 0.3s" },
  planCardPopular: { background: "rgba(245,158,11,0.04)", transform: "scale(1.02)" },
  popularTag: { position: "absolute", top: -12, left: "50%", transform: "translateX(-50%)", padding: "4px 16px", borderRadius: 20, fontSize: 11, fontWeight: 700, color: "#fff", letterSpacing: 1 },
  planName: { fontSize: 20, fontWeight: 700, marginBottom: 8, marginTop: 8 },
  planPrice: { display: "flex", alignItems: "baseline", gap: 2, marginBottom: 24 },
  priceCurrency: { fontSize: 20, fontWeight: 600, color: "#9ca3af" },
  priceAmount: { fontSize: 44, fontWeight: 800 },
  priceInterval: { fontSize: 16, color: "#6b7280" },
  featuresList: { listStyle: "none", padding: 0, marginBottom: 28 },
  featureItem: { display: "flex", alignItems: "center", gap: 10, padding: "8px 0", fontSize: 14, color: "#d1d5db" },
  planBtn: { width: "100%", padding: "14px 0", border: "none", borderRadius: 12, color: "#fff", fontSize: 15, fontWeight: 700, cursor: "pointer", fontFamily: "inherit", transition: "opacity 0.2s" },

  // Chat
  chatContainer: { height: "calc(100vh - 64px)", display: "flex", flexDirection: "column" },
  videoArea: { height: "60%", position: "relative", background: "#0f0f17", borderRadius: "16px 16px 0 0", overflow: "hidden", margin: "16px 0 0" },
  strangerVideo: { width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center" },
  videoPlaceholder: { display: "flex", flexDirection: "column", alignItems: "center", gap: 8 },
  strangerAvatar: { width: 80, height: 80, borderRadius: "50%", background: "rgba(255,255,255,0.05)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 40 },
  selfVideo: { position: "absolute", bottom: 16, right: 16, width: 160, height: 120, borderRadius: 12, overflow: "hidden", background: "#1a1a2e", border: "2px solid rgba(255,255,255,0.1)" },
  selfVideoEl: { width: "100%", height: "100%", objectFit: "cover", transform: "scaleX(-1)" },
  camOffOverlay: { position: "absolute", inset: 0, background: "rgba(0,0,0,0.8)", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 4 },
  videoControls: { position: "absolute", bottom: 16, left: "50%", transform: "translateX(-50%)", display: "flex", gap: 12 },
  controlBtn: { width: 44, height: 44, borderRadius: "50%", border: "1px solid rgba(255,255,255,0.15)", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", transition: "background 0.2s" },
  searchingSpinner: { width: 48, height: 48, border: "3px solid rgba(255,255,255,0.1)", borderTop: "3px solid #3b82f6", borderRadius: "50%", animation: "spin 1s linear infinite" },

  chatArea: { flex: 1, display: "flex", flexDirection: "column", background: "rgba(255,255,255,0.02)", borderRadius: 16, border: "1px solid rgba(255,255,255,0.06)", margin: "8px 0 16px", overflow: "hidden" },
  chatHeader: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px 16px", borderBottom: "1px solid rgba(255,255,255,0.06)", flexWrap: "wrap", gap: 8 },
  backBtn: { padding: "6px 14px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, color: "#e5e7eb", fontSize: 13, cursor: "pointer", fontFamily: "inherit" },
  chatStatus: { display: "flex", alignItems: "center", gap: 6, fontSize: 14, color: "#9ca3af" },
  searchDot: { width: 8, height: 8, borderRadius: "50%", background: "#f59e0b", animation: "pulse-glow 1.5s infinite" },
  chatActions: { display: "flex", gap: 8 },
  skipBtn: { display: "flex", alignItems: "center", gap: 6, padding: "6px 16px", background: "rgba(59,130,246,0.15)", border: "1px solid rgba(59,130,246,0.3)", borderRadius: 8, color: "#60a5fa", fontSize: 13, fontWeight: 600, cursor: "pointer", fontFamily: "inherit" },
  stopBtn: { display: "flex", alignItems: "center", gap: 6, padding: "6px 16px", background: "rgba(239,68,68,0.15)", border: "1px solid rgba(239,68,68,0.3)", borderRadius: 8, color: "#f87171", fontSize: 13, fontWeight: 600, cursor: "pointer", fontFamily: "inherit" },

  messagesArea: { flex: 1, overflowY: "auto", padding: 16, display: "flex", flexDirection: "column", gap: 8 },
  messageBubble: { padding: "10px 16px", borderRadius: 14, maxWidth: "75%", fontSize: 14, lineHeight: 1.5, wordBreak: "break-word" },
  youBubble: { alignSelf: "flex-end", background: "linear-gradient(135deg, #3b82f6, #6366f1)", color: "#fff", borderBottomRightRadius: 4 },
  strangerBubble: { alignSelf: "flex-start", background: "rgba(255,255,255,0.06)", color: "#e5e7eb", borderBottomLeftRadius: 4 },
  systemBubble: { alignSelf: "center", background: "transparent", color: "#6b7280", fontSize: 13, textAlign: "center", padding: "4px 12px" },
  msgSender: { display: "block", fontSize: 11, fontWeight: 700, marginBottom: 2, opacity: 0.7, letterSpacing: 0.3 },
  typingDots: { display: "flex", gap: 2, fontSize: 22, lineHeight: 1 },

  inputArea: { display: "flex", gap: 8, padding: 12, borderTop: "1px solid rgba(255,255,255,0.06)" },
  chatInput: { flex: 1, padding: "12px 16px", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 12, color: "#e5e7eb", fontSize: 14, outline: "none", fontFamily: "inherit" },
  sendBtn: { width: 44, height: 44, borderRadius: 12, background: "linear-gradient(135deg, #3b82f6, #6366f1)", border: "none", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" },

  // Auth Modal
  modalOverlay: { position: "fixed", inset: 0, zIndex: 200, background: "rgba(0,0,0,0.7)", backdropFilter: "blur(8px)", display: "flex", alignItems: "center", justifyContent: "center", padding: 20 },
  modalContent: { width: "100%", maxWidth: 400, background: "#14141f", borderRadius: 24, border: "1px solid rgba(255,255,255,0.08)", padding: 36, position: "relative" },
  modalClose: { position: "absolute", top: 16, right: 16, background: "none", border: "none", color: "#6b7280", fontSize: 20, cursor: "pointer" },
  modalTitle: { fontSize: 26, fontWeight: 800, marginBottom: 4, letterSpacing: -0.5 },
  modalSub: { fontSize: 14, color: "#6b7280", marginBottom: 28 },
  modalInput: { width: "100%", padding: "14px 16px", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 12, color: "#e5e7eb", fontSize: 14, marginBottom: 12, outline: "none", fontFamily: "inherit" },
  modalSubmitBtn: { width: "100%", padding: "14px 0", background: "linear-gradient(135deg, #3b82f6, #6366f1)", border: "none", borderRadius: 12, color: "#fff", fontSize: 15, fontWeight: 700, cursor: "pointer", fontFamily: "inherit", marginTop: 4 },
  divider: { display: "flex", alignItems: "center", gap: 12, margin: "20px 0" },
  dividerLine: { flex: 1, height: 1, background: "rgba(255,255,255,0.08)" },
  dividerText: { fontSize: 12, color: "#6b7280" },
  googleBtn: { width: "100%", padding: "12px 0", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 12, color: "#e5e7eb", fontSize: 14, fontWeight: 500, cursor: "pointer", fontFamily: "inherit", display: "flex", alignItems: "center", justifyContent: "center", gap: 10 },
  switchAuth: { marginTop: 20, fontSize: 14, color: "#6b7280", textAlign: "center" },
  switchBtn: { background: "none", border: "none", color: "#3b82f6", fontWeight: 600, cursor: "pointer", fontFamily: "inherit", marginLeft: 4, fontSize: 14 },
};
